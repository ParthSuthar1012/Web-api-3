﻿using practical1.Models;


namespace Repository.Repository.IRepository
{
    public interface IOrderItemRepository : IRepository<OrderItem>
    {
       
     
    }
}
