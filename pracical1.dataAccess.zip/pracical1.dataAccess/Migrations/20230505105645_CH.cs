﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace pracical1.dataAccess.Migrations
{
    public partial class CH : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
