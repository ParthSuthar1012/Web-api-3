﻿namespace pracical1.dataAccess
{
    public class Class1
    {

    }
}